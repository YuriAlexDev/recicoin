package com.example.loginapi;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginCredentials credentials) {
        if ("yurirecicoin".equals(credentials.getUsername()) && "yurirecicoin123".equals(credentials.getPassword())) {
            return ResponseEntity.ok("Conectado com sucesso");
        }
        return ResponseEntity.status(401).body("Credenciais inválidas");
    }

    @GetMapping("/profile")
    public ResponseEntity<?> getProfile() {
        // Apenas uma demonstração que o usuário está conectado ao perfil.
        return ResponseEntity.ok("Bem-vindo ao seu perfil!");
    }
}


